create definer = root@localhost view hotel1 as
select `mydb`.`hotel`.`hotel_name` AS `city_name`, `mydb`.`country`.`country_name` AS `country_name`
from (`mydb`.`hotel`
         join (`mydb`.`city` join `mydb`.`country` on ((`mydb`.`city`.`country_country_num` = `mydb`.`country`.`country_num`)))
              on ((`mydb`.`hotel`.`city_idcity` = `mydb`.`city`.`idcity`)))
where (`mydb`.`hotel`.`hotel_price` <= (select avg(`mydb`.`hotel`.`hotel_price`) from `mydb`.`hotel`));

