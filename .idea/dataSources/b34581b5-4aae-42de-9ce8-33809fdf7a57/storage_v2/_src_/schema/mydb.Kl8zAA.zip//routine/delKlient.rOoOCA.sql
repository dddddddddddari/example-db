create
    definer = root@localhost procedure delKlient(IN klient_num int)
begin
    delete from mydb.klient 
    where id=klient_num;
end;

