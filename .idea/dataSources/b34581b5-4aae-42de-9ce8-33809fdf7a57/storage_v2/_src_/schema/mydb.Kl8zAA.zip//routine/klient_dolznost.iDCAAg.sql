create
    definer = root@localhost procedure klient_dolznost(IN dolznost varchar(40))
BEGIN
SELECT * from klient
Where dolznost = dolznost;
END;

