create
    definer = root@localhost procedure num_pasport(IN num_pasport varchar(40))
BEGIN
SELECT * from klient
Where num_pasport = num_pasport;
END;

