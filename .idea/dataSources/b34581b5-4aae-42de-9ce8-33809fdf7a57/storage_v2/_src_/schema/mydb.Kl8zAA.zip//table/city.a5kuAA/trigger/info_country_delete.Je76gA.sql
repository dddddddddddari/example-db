create definer = root@localhost trigger info_country_delete
    after delete
    on city
    for each row
BEGIN

DELETE FROM city
WHERE country_num=OLD.country_country_num;
END;

