create view new_view as
select `mydb`.`klient`.`klient_name`   AS `klient_name`,
       `mydb`.`city`.`city_name`       AS `city_name`,
       `mydb`.`country`.`country_name` AS `country_name`,
       `mydb`.`hotel`.`hotel_name`     AS `type_food`,
       `mydb`.`hotel`.`hotel_zvezda`   AS `hotel_zvezda`,
       `mydb`.`tour`.`tour_type`       AS `tour_type`,
       `mydb`.`room`.`type_room`       AS `type_room`,
       `mydb`.`reis`.`data_vilet`      AS `data_vilet`,
       `mydb`.`reis`.`data_prilet`     AS `data_prilet`
from ((((((((`mydb`.`contract` join `mydb`.`klient`) join `mydb`.`city`) join `mydb`.`hotel`) join `mydb`.`tour`) join `mydb`.`room`) join `mydb`.`food`) join `mydb`.`reis`)
         join `mydb`.`country` on ((`mydb`.`contract`.`tour_tour_num` = `mydb`.`tour`.`tour_num`)))
where (`mydb`.`contract`.`contract_prime` <= (select avg(`mydb`.`contract`.`contract_prime`) from `mydb`.`contract`));

