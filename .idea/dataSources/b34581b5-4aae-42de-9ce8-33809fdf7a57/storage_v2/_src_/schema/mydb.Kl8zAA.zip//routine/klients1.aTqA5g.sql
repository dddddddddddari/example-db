create
    definer = root@localhost procedure klients1(IN klient_name varchar(45), IN klient_data date,
                                                IN klient_addr varchar(45), IN klient_fhone varchar(9))
BEGIN
declare klient_num int;
insert into klient ( klient_name , klient_data , klient_addr, klient_fhone )
values ( klient_name , klient_data , klient_addr, klient_fhone );
end;

